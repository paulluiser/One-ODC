ONE ODC — BRAND KIT
Every space. One vision.

Original SVG wordmarks, symbols, app icons, PNG exports, design tokens, locally bundled Inter fonts and license are in public/.
View public/brand/one-odc-brand-board.png for the complete identity board.
Brand guidance, sourced company research and contrast results are in docs/.
The working application foundation is in the separate One ODC workspace repository.
